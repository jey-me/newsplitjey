import React from 'react';
import ShoppingList from '../components/ShoppingList';

export default function ShoppingPage() {
  return (
    <div style={{ padding: '16px', paddingBottom: '80px' }}>
            <ShoppingList />
    </div>
  );
}
